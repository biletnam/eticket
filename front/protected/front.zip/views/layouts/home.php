<?php $this->renderFile(Yii::app()->basePath . "/views/_shared/header.php"); ?>

<?php echo $content; ?>

<?php $this->renderFile(Yii::app()->basePath . "/views/_shared/footer.php"); ?>
