<?php if(isset($paging) && $paging != ""): ?>
<div class="paging">
    <div class="pagination">
        <ul>
            <?php echo $paging; ?>
        </ul>
    </div>
</div>
<?php endif;?>
