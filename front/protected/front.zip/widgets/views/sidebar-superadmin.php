<div id="sidebar" class="span2 bs-docs-sidebar">
    <ul class="nav nav-list bs-docs-sidenav affix well">
        <li class="nav-header"></i>DATA</li>
        <li><a href="<?php echo HelperUrl::baseUrl() ?>category/"><i class="icon-th"></i>Categories</a></li>
        
        <li><a href="<?php echo HelperUrl::baseUrl() ?>faq/"><i class="icon-info-sign"></i>Faqs</a></li>
        
        <li class="nav-header"></i>SYSTEM</li>
        
        <li><a href="<?php echo HelperUrl::baseUrl() ?>admin/"><i class="icon-eye-open"></i> Administrators</a></li>
        <li><a href="<?php echo HelperUrl::baseUrl() ?>log/"><i class="icon-warning-sign"></i> Logs</a></li>
        
    </ul>
</div>