<div id="sidebar" class="span2 bs-docs-sidebar">
    <ul class="nav nav-list bs-docs-sidenav affix well">
        <li class="nav-header"></i>DATA</li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/category/"><i class="icon-th"></i>Categories</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/event/"><i class="icon-map-marker"></i>Events</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/event/pending"><i class="icon-map-marker"></i>Event Pending</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/ticket/"><i class="icon-map-marker"></i>Tickets</a></li>
        
          <li><a href="<?php echo Yii::app()->request->baseUrl ?>/organizer"><i class="icon-map-marker"></i>Organizer</a></li>
        
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/location"><i class="icon-map-marker"></i>Location</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/location/city"><i class="icon-map-marker"></i>City</a></li>
        
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/faq/"><i class="icon-info-sign"></i>FAQs</a></li>

        <li class="nav-header"></i>SYSTEM</li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/page"><i class="icon-book"></i>Pages</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/user/"><i class="icon-user"></i>Users</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/user/pending"><i class="icon-user"></i>Client Pending</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/admin/"><i class="icon-eye-open"></i>Administrators</a></li>
        <li><a href="<?php echo Yii::app()->request->baseUrl ?>/log/"><i class="icon-warning-sign"></i>Logs</a></li>

    </ul>
</div>