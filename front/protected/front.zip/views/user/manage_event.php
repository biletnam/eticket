
<section class="manage-event">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th width="180px">EVENT NAME</th>
                <th>DATE</th>
                <th>STATUS</th>
                <th>SOLD</th>
                <th>QUICK LINKS</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($events as $e): ?>
            <tr>
                <td class="text-bold"> <a href="<?php echo HelperUrl::baseUrl()?>event/details/s/<?php echo $e['slug']?>"><?php echo $e['title']?> </a></td>
                <td><?php echo date('M j, Y',strtotime($e['start_time']))?></td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="<?php echo HelperUrl::baseUrl()?>event/edit/id/<?php echo $e['id']?>"> Edit </a>
                        <a class="btn-style" href="<?php echo HelperUrl::baseUrl()?>event/details/s/<?php echo $e['slug']?>">View</a>
                        <a class="btn-style btn-invite"  href="#invite_<?php echo $e['id']?>">Invite</a>
                    </div>
                </td>
            </tr>
            
        <div id="invite_<?php echo $e['id']?>" style="display: none">
            <form class="form-style" method="post">
                <div class="controls-group clearfix">
                    <label class="control-label pull-left">Email</label>
                    <div class="controls pull-left">
                        <input type="text" class="input-medium" name="email"/>
                    </div>
                </div>
                
                <div class="controls-group clearfix">
                    <label class="control-label pull-left">Subject</label>
                    <div class="controls pull-left">
                        <input type="text" class="input-medium" name="subject"/>
                    </div>
                </div>
                
                <div class="controls-group clearfix">
                    <label class="control-label pull-left">Message</label>
                    <div class="controls pull-left">
                        <textarea class="input-medium" name="message"></textarea>
                    </div>
                </div>
                <div class="controls-group clearfix">
                    <label class="control-label pull-left">&nbsp;</label>
                    <div class="controls pull-left">
                        <input type="submit" class="btn" value="Send"/>
                    </div>
                </div>
            </form>
        </div>
            
            <?php endforeach; ?>
            
           
        </tbody>
    </table>
</section>
