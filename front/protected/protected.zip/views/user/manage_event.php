
<section class="manage-event">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th width="200px">EVENT NAME</th>
                <th>DATE</th>
                <th>STATUS</th>
                <th>SOLD</th>
                <th>QUICK LINKS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>Apr 18, 2013</td>
                <td>Live</td>
                <td>2/20</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Edit</a>
                        <a class="btn-style" href="#">View</a>
                        <a class="btn-style" href="#">Invite</a>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</section>
