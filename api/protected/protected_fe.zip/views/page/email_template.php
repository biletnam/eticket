<link rel="stylesheet" href="<?php echo HelperUrl::baseUrl(); ?>css/email.css" />
<div style="font-family:'bebasneue',Tahoma,Verdana;font-size:20px;color:#000;margin:0 auto;padding:0;width: 500px">
    <div class="header">
        <div class="logo" style="background: url('<?php echo HelperUrl::baseUrl() ?>img/logo.png') no-repeat 10px top;width: 196px;height: 110px">&nbsp;</div>
    </div>
    <div class="title" style="font-family: 'bebasneue',Tahoma,Verdana;font-size:30px; background-color: #414143;color:#fff;padding: 5px 10px;text-transform: capitalize;margin-bottom: 10px">
        Payment Event
    </div>
    <div class="content" style="font-family: 'bebasneue',Tahoma,Verdana;padding:10px">
        <p style="margin-bottom: 10px">Congatulations,</p>
        <p style="margin-bottom: 10px">Your Event has been successfully created.</p>
        <p>
            Regards,<br/>
            The 360 Island Events Team.    
        </p>
        <a href="#"><img src="<?php echo HelperUrl::baseUrl()?>img/email_fb.png"/></a>
        <a href="#"><img src="<?php echo HelperUrl::baseUrl()?>img/email_tw.png"/></a>
    </div>
</div>