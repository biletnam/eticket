<section class="support-assist">
    <h4> Can't find what you're looking for?  </h4>
    <p>
        Call <span class="label label-info">012 345 6789</span> or contact us by click <a href="<?php echo HelperUrl::baseUrl() ?>page/contact_us">here</a>
    </p>
</section>