<section class="manage-event">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th width="220px">TICKET</th>
                <th width="220px">EVENT</th>
                <th>QUANTITY</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
            <tr>
                <td><a href="#">Ticket 1</a></td>
                <td class="text-bold"><a href="#">Holiday summer event</a></td>
                <td>2</td>
                <td>
                    <div>
                        <a class="btn-style btn-primary" href="#">Detail</a>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</section>