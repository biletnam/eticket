<div class="page padding-bottom-50px">
    <div class="container_12">
        <div class="cleafix">
            <section class="grid_12">
                <article class="border border-radius form-style">
                    <?php echo $message ?>
                </article>
            </section>
        </div>
    </div>
</div>