<div id="sidebar" class="span2 bs-docs-sidebar">
    <ul class="nav nav-list bs-docs-sidenav affix well">
        <li class="nav-header"></i>DATA</li>
        <li><a href="<?php echo HelperUrl::baseUrl() ?>category/"><i class="icon-th"></i>Categories</a></li>
        
    </ul>
</div>